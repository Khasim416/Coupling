﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CouplingExample.Models
{
    public class CoverType
    {
        // Creating Table or Properties inside the database

        [Key]
        public int Id { get; set; }
        [Display(Name="Cover Type")]
        [Required]
        public string Name { get; set; }
    }
}
